const router = require('express').Router()
const db = require("../models")
const bcrypt = require('bcrypt')
const jwt = require('json-web-token')

const { User } = db

router.post('/', async (req, res) => {

    let user = await User.findOne({
        where: { email: req.body.email }
    })

    console.log("POST:  ------------------------------------------------------")
    console.log("EMAIL:  " + req.body.email)
    console.log("PASSWD: " + req.body.password)

    

    if (!user || !await bcrypt.compare(req.body.password, user.passwordDigest)) {
        res.status(404).json({ message: `Could not find a user with the provided username and password` })
    } else {
        const result = await jwt.encode(process.env.JWT_SECRET, { id: user.userId })
        res.json({ user: user, token: result.value })

        console.log("USER:")
        console.log(user)

        console.log("TOKEN = " + result.value)
    }
})

  
router.get('/profile', async (req, res) => {
    res.json(req.currentUser)
})
/*
router.get('/profile', async (req, res) => {
    try {
        const [method, token] = req.headers.authorization.split(' ')
        if (method == 'Bearer') {
            console.log("****************** PROFILE GET ****************************")
            console.log(process.env.JWT_SECRET)
            console.log(token)

            const result = await jwt.decode(process.env.JWT_SECRET, token)
            console.log(result)

            
            const { id } = result.value
            let user = await User.findOne({
                where: {
                    userId: id
                }
            })
            res.json(user)
        }
    } catch (err) {
        res.json(null)
    }
})
*/
module.exports = router